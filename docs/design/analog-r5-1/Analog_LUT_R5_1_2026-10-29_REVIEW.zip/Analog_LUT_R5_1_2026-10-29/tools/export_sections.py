#!/usr/bin/env python3
"""Readable vector crops of the ONE authoritative wired KiCad schematic.
These pages are views, not additional electrical sheets or substitute labels.
"""
from pathlib import Path
import fitz,json
P=Path(__file__).resolve().parent.parent/'kicad';src=fitz.open(P/'analog-input-r5.pdf');out=fitz.open();mm=72/25.4
views=[
 ('01_input','Вход CH1 и две секции одного переключателя S1',(15,51,190,242)),
 ('02_attenuator','Делитель, смещение и входной буфер U1A',(177,51,414,180)),
 ('03_sensitivity','U1D: обратная связь и выбор чувствительности',(408,51,565,247)),
 ('04_filter1','Первое звено фильтра: реальные проводники C1 и C8',(29,252,258,384)),
 ('05_filter2','Второе звено фильтра: C3 на выход U1C, C4 на AGND',(263,252,459,384)),
 ('06_adc','Выходной RC-фильтр, перемычка JP1 и разъём J2',(448,279,580,366)),
 ('07_supply','Общая шина питания и все выводы питания U1',(185,180,400,243)),
]
font='C:/Windows/Fonts/arial.ttf'
for name,title,box in views:
 portrait=(box[2]-box[0])/(box[3]-box[1])<1.25
 width,height=(210,297) if portrait else (297,210)
 page=out.new_page(width=width*mm,height=height*mm);page.insert_font(fontname='DV',fontfile=font)
 page.insert_textbox(fitz.Rect(12*mm,10*mm,(width-12)*mm,26*mm),title,fontname='DV',fontsize=12.5)
 page.insert_textbox(fitz.Rect(12*mm,28*mm,(width-12)*mm,40*mm),'Фрагмент единого KiCad-листа. Все сигнальные связи — проводники.\nИмена сетей — поясняющий текст, а не электрические labels.',fontname='DV',fontsize=8.5)
 clip=fitz.Rect(*(x*mm for x in box));target=fitz.Rect(10*mm,44*mm,(width-10)*mm,(height-28)*mm)
 page.show_pdf_page(target,src,0,clip=clip,keep_proportion=True)
 page.insert_textbox(fitz.Rect(12*mm,(height-23)*mm,(width-12)*mm,(height-8)*mm),'Обрезанные на краю проводники продолжаются на полном листе analog-input-r5.pdf.\n96/104 пФ: материал и посадка требуют проверки. НЕ ТРАВИТЬ. Опытов с автомобилем нет.',fontname='DV',fontsize=8)
out.save(P.parent/'docs'/'Schematic_sections_RU.pdf',garbage=4,deflate=True)
(P.parent/'verification'/'schematic_section_regions.json').write_text(json.dumps({'source':'../analog-input-r5.pdf','units':'mm','views':views,'authority':'Single A2 KiCad sheet; these are vector crops only.'},ensure_ascii=False,indent=2)+'\n')
print('Exported',len(views),'vector detail pages')
