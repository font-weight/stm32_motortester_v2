ВОСПРОИЗВЕДЕНИЕ
Расчёты автономны: запускать calculations/calculate_x7r.py и
calculations/check_observed_cases.py с установленными numpy/scipy.
Точные версии и численные проверки записаны в calculations.

KiCad: открыть kicad/analog-input-r5.kicad_pro. Пример новых проверок:
kicad-cli sch erc --format json -o erc.json kicad/analog-input-r5.kicad_sch
kicad-cli pcb drc --format json --schematic-parity -o drc.json kicad/analog-input-r5.kicad_pcb
Действующий DRC содержит 8 ошибок, см.STATUS_RU.txt. Не добавлять исключения
только ради нулевого счётчика.

build_handbook_review.py — исходник простого руководства. Требует python-docx.
Запуск из копии комплекта пересоздаёт Word, README, текст промпта и список ссылок.
PDF затем заново экспортировать из Word/LibreOffice и проверить страницы.
Для обычной ручной правки можно редактировать DOCX; не запускать генератор
после ручной правки, иначе он заменит документ своим исходным текстом.
Прежние генераторы платы находятся внутри R4ZIP и НЕ предназначены для R5:
их запуск вернёт старые значения C10/C11 и старые примечания.

PDF ЛУТ не пересозданы, потому что геометрия не менялась. Побайтная сохранность
проверена вfile_manifest.json. Если меняется посадка — необходим новый экспорт.
