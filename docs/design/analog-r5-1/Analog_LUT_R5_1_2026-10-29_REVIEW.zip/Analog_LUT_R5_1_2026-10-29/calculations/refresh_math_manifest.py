"""Обновить контрольные суммы текущих файлов этой папки."""
from pathlib import Path
import json, hashlib
p=Path(__file__).resolve().parent
names=['model_r4.py','baseline-r2-netlist.json','calculate_x7r.py',
       'x7r_results.json','x7r_cases.csv','README_RU.txt',
       'check_observed_cases.py','r4_observed_band_cases.json',
       'observed_cases.json','requirements.txt','actual_assignment.json',
       'actual_assignment.txt','refresh_math_manifest.py',
       'beginner_checks.py','beginner_checks.json','beginner_checks.txt']
old=json.loads((p/'MATH_MANIFEST.json').read_text(encoding='utf-8')) if (p/'MATH_MANIFEST.json').exists() else {}
out={'source_archive':'Analog_LUT_R4_2026-10-26.zip',
     'source_archive_sha256':'84b3c4d63d656fbaa319a16f9e97e1a0658d00331b6bccf389566b2c5b9b238b',
     'model_change':'only ROOT and netlist file lookup changed; nominal values and equations unchanged',
     'source_model_sha256':old.get('source_model_sha256'),
     'actual_parts':'user-reported leaded capacitors 96 pF and 104 pF; dielectric unknown, suspected X7R; measurement accuracy unknown',
     'files':{x:hashlib.sha256((p/x).read_bytes()).hexdigest() for x in names}}
(p/'MATH_MANIFEST.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(names),'files')
