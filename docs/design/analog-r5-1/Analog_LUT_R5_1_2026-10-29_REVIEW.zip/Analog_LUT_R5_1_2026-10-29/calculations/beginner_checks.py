"""Расчётные ориентиры первого включения; это НЕ критерии приёмки платы.
Запуск из любого каталога: python beginner_checks.py
Пишет только beginner_checks.json. Нужны model_r4.py и его JSON рядом,
а также экспорт реальной схемы ../kicad/analog-input-r5.net.xml.
"""
from pathlib import Path
import hashlib, itertools, json
import xml.etree.ElementTree as ET
import numpy as np
from model_r4 import Circuit, NOMINAL, MODES

P=Path(__file__).resolve().parent
NET=P.parent/'kicad/analog-input-r5.net.xml'
groups={n.attrib['name']:{f"{x.attrib['ref']}.{x.attrib['pin']}" for x in n.findall('node')} for n in ET.parse(NET).getroot().findall('./nets/net')}
definitions={
 'AGND':('J3.2',{'J3.2','J1.2','J2.2','U1.11'}),
 'V_A':('J3.1',{'J3.1','U1.4'}),
 'BUF':('U1.1',{'U1.1','U1.2','U1.12'}),
 'DRIVE':('U1.14',{'U1.14','S2.1','R5.1'}),
 'LP1':('U1.7',{'U1.7','U1.6','R7.1'}),
 'LP2':('U1.8',{'U1.8','U1.9','R9.1'}),
 'ADC_NODE':('JP1.1',{'JP1.1','C5.1','R9.2'}),
}
points={}
for logical,(probe,required) in definitions.items():
 names=[name for name,pins in groups.items() if required<=pins]
 assert len(names)==1,(logical,names)
 points[logical]={'red_probe':probe,'black_probe':'J3.2','actual_net_name':names[0],'checked_pins':sorted(required),'same_net_verified':True}

RS=['R1','R2','R3','R4','R14','R15','R16','R17']
NODES=['BUF','DRIVE','LP1','LP2','ADC_NODE']
sets=[]
for signs in itertools.product([-.01,.01],repeat=len(RS)):
 vals={k:NOMINAL[k]*(1+s) for k,s in zip(RS,signs)}
 vals.update({'C10':96e-12,'C11':104e-12})
 sets.append(vals)

data={}
for mode in MODES:
 records=[]
 for vals in sets:
  c=Circuit(mode,vals)
  zero=c.dc(vin=0,va=1)
  records.append({'zero_per_VA':{n:zero[n] for n in NODES},'gain':c.gain(),
                 'dc_plus1_at3p3':c.dc(vin=1,va=3.3),
                 'dc_minus1_at3p3':c.dc(vin=-1,va=3.3)})
 nominal=Circuit(mode,{'C10':96e-12,'C11':104e-12})
 row={'corner_count':len(records),'zero_condition':'CH1 shorted to AGND after removing the external signal source; settled DC state; S1/S2 changed only with power off',
      'nodes':{},'middle_band_gain_V_per_V':[min(x['gain'] for x in records),max(x['gain'] for x in records)]}
 for node in NODES:
  lo=min(x['zero_per_VA'][node] for x in records); hi=max(x['zero_per_VA'][node] for x in records)
  assert lo>0
  row['nodes'][node]={'nominal_zero_at3p3_V':nominal.dc(vin=0,va=3.3)[node],
    'zero_over_VA':[lo,hi],
    'zero_at_VA3p3_V':[lo*3.3,hi*3.3],
    'zero_at_VA3p2_to3p4_V':[lo*3.2,hi*3.4]}
 if mode=='DC_WIDE':
  row['plus_minus1V_DC']={}
  for node in NODES:
   plus=[x['dc_plus1_at3p3'][node] for x in records]
   minus=[x['dc_minus1_at3p3'][node] for x in records]
   # Здесь при DC все пять узлов — повторители одного входного делителя.
   gains=row['middle_band_gain_V_per_V']
   row['plus_minus1V_DC'][node]={'change_for_plus1_V':[gains[0],gains[1]],
    'change_for_minus1_V':[-gains[1],-gains[0]],
    'absolute_plus1_at3p3_V':[min(plus),max(plus)],
    'absolute_minus1_at3p3_V':[min(minus),max(minus)],
    'nominal_change_for_plus1_V':nominal.gain()}
 data[mode]=row

# Независимо сверяем пересчитанные крайние выходные значения с результатами R4.
# В R4 C10/C11 были по100пФ; на установившийся DC это не влияет в данной модели.
expected={'DC_WIDE':{'gain':[0.03627780270380917,0.037702556781452616],'zero':[1.6433228029090745,1.6763216333864326]},
          'AC_WIDE':{'gain':[0.03593824889797643,0.03735018436072639],'zero':[1.7070923341617323,1.7400267396702178]},
          'AC_SENSITIVE':{'gain':[0.1798231598202973,0.1929909821685381],'zero':[1.5711506191720523,1.8758472867723883]}}
err=0.
for mode,e in expected.items():
 err=max(err,max(abs(np.array(data[mode]['middle_band_gain_V_per_V'])-e['gain'])),max(abs(np.array(data[mode]['nodes']['ADC_NODE']['zero_at_VA3p3_V'])-e['zero'])))
assert err<1e-11,err

out={'title':'Первое включение: расчётные ориентиры, не критерии PASS',
 'provenance':{'model':'model_r4.py, unchanged R4 equations; only data path changed',
  'model_sha256':hashlib.sha256((P/'model_r4.py').read_bytes()).hexdigest(),
  'baseline_netlist_sha256':hashlib.sha256((P/'baseline-r2-netlist.json').read_bytes()).hexdigest(),
  'checked_real_schematic_netlist':'../kicad/analog-input-r5.net.xml',
  'checked_real_schematic_netlist_sha256':hashlib.sha256(NET.read_bytes()).hexdigest(),
  'R4_reference':'calculations/results.json, resistor_1pct_corners_at_3p3',
  'R4_results_sha256':'73cfa72cec7b683cead96ff3aeb24e6147bf71503ba3b07138048e6a9d72d85f',
  'R4_comparison_max_abs_error':float(err)},
 'assumptions':{'varied_resistors':RS,'independent_resistor_tolerance_fraction':.01,
  'corners_per_mode':256,'C10_C11_F':[96e-12,104e-12],
  'other_parts':'Nominal values; ideal opamps; zero input current, offset voltage and capacitor leakage',
  'VA_V_for_tables':[3.3,[3.2,3.4]],
  'important':'3.2..3.4V is the R4 calculation interval, not a new acceptance or safety specification. The actual part tolerances are unconfirmed. These ranges do not include unknown Vos, leakage, measurement uncertainty, wiring, startup or ADC loading.'},
 'measurement_points':points,'modes':data,
 'use':'Find obvious assembly or mode errors; a value inside a range is NOT PASS and outside is not automatically a faulty board. Stop and investigate unexplained deviations before connecting ADC or increasing a test signal.',
 'physical_testing':'NOT_PERFORMED'}
(P/'beginner_checks.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({'points_verified':list(points),'max_R4_error':float(err),'modes':data},ensure_ascii=False,indent=2))
