from pathlib import Path
import json, sys
from model_r4 import Circuit, NOMINAL
p=Path(__file__).resolve().parent/'r4_observed_band_cases.json'
d=json.loads(p.read_text())
out=[]
for row in d['results']:
 for kind in ['minimum_at15k','maximum_at20k']:
  vals={}; pars={}
  for k,x in zip(d['keys'],row[kind]['parameters_normalized']):
   if k in d['parasitic_maxima_SI']:pars[k]=x*d['parasitic_maxima_SI'][k]
   else: vals[k]=NOMINAL[k]*(1+x*(.01 if k.startswith('R') else .02 if k=='C11' else row['effective_filter_cap_tolerance'] if k in ['C1','C8','C2','C3','C4'] else .05))
  before=Circuit(values=vals,parasitics=pars).cutoff()
  assert abs(before-row[kind]['cutoff_of_observed_case_Hz'])<1e-5
  for cc in [95.,105.,80.75,120.75]:
   vv=vals|{'C11':cc*1e-12}
   out.append({'R4_case':kind,'other_filter_C_tolerance':row['effective_filter_cap_tolerance'],'C11_pF':cc,'cutoff_Hz':Circuit(values=vv,parasitics=pars).cutoff(),'values_SI':vv,'parasitics_SI':pars,'warning':'observed R4 case with changed C11; not extremum proof'})
(Path(__file__).resolve().parent/'observed_cases.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps([{k:v for k,v in x.items() if k not in ['values_SI','parasitics_SI']} for x in out],indent=2))
