"""Выводные керамические C10/C11: тип неизвестен, предположительно X7R.
Запуск: python calculate_x7r.py.

Ничего не пишет в R4. Это расчёт линейной модели, а не проверка платы.
Номиналы и MNA-модель взяты из R4; model_r4.py отличается только путём к JSON.
Пользователь сообщил две детали: 96 и 104 пФ. Точность измерений неизвестна.
95..105 пФ — ранее сообщённый допуск. 80.75..120.75 — условный пример,
только если это X7R; в нём учтены лишь допуск и температура.
50..200 пФ — условные примеры, НЕ границы для имеющихся деталей.
"""
from pathlib import Path
import csv, hashlib, itertools, json, platform
import numpy as np
import scipy
from scipy.linalg import svd, eig
from scipy.signal import step, TransferFunction
from numpy.polynomial import Polynomial as Poly
from model_r4 import Circuit, NOMINAL, MODES, algebraic_total

HERE = Path(__file__).resolve().parent

def normalized_dc_tf(c11):
    """Отдельный расчёт передаточной функции DC для проверки MNA."""
    r = NOMINAL
    rt = 1/(1/(r['R1']+r['R2'])+1/r['R3']+1/r['R4'])
    cs = 20e-12
    den = Poly([1, rt*(cs+c11)+r['R18']*c11, rt*r['R18']*cs*c11])
    for ra, rb, cf, cg in [('R5','R6',r['C1']+r['C8'],r['C2']), ('R7','R8',r['C3'],r['C4'])]:
        den *= Poly([1, cg*(r[ra]+r[rb]), r[ra]*r[rb]*cf*cg])
    den *= Poly([1, r['R9']*r['C5']])
    # Время в микросекундах: это избегает плохой численной обусловленности
    # многополюсной системы в стандартной форме scipy.signal.
    scaled = den.coef / (1e-6 ** np.arange(len(den.coef)))
    return TransferFunction([1], scaled[::-1])

def ideal_step(c11):
    tf = normalized_dc_tf(c11)
    f=np.geomspace(1,1e7,180)
    z=2j*np.pi*f*1e-6
    check=np.polyval(tf.num,z)/np.polyval(tf.den,z)
    c=Circuit('DC_WIDE',values={'C11':c11})
    assert np.max(abs(check-c.response(f)/c.gain())) < 1e-10
    t = np.linspace(0, 400e-6, 8001)
    _, y = step(tf, T=t/1e-6)
    assert np.all(np.isfinite(y))
    outside = np.flatnonzero(abs(y-1) > .01)
    last = (t[outside[-1]+1]*1e6 if len(outside) and outside[-1]+1 < len(t) else None)
    return {'overshoot_pct': float((y.max()-1)*100), 'peak_us':float(t[np.argmax(y)]*1e6), 'settling_1pct_us_sampled':float(last) if last else None,'step_transfer_MNA_max_error':float(np.max(abs(check-c.response(f)/c.gain())))}

def reduce_descriptor(c):
    """Формулы R4/transient.py без исполняемой части, которая пишет в R4."""
    unit=1e-6
    U,s,Vh=svd(c.Cs/unit); rank=int(sum(s>s[0]*1e-12)); V=Vh.T
    g=U.T@c.Gs@V; bg=U.T@c.Bgs[:,0]; bc=U.T@c.Bcs[:,0]/unit
    gd=g[:rank,:rank]; ga=g[:rank,rank:]; ag=g[rank:,:rank]; aa=g[rank:,rank:]
    assert np.max(abs(bc[rank:])) < 1e-10
    ax=-np.linalg.solve(aa,ag); au=np.linalg.solve(aa,bg[rank:])
    A=-(gd+ga@ax)/s[:rank,None]; B=(bg[:rank]-ga@au)/s[:rank]; D=bc[:rank]/s[:rank]
    X=V[:,:rank]+V[:,rank:]@ax; Y=V[:,rank:]@au
    Bd=B+A@D; direct=Y+X@D; dc=direct-X@np.linalg.solve(A,Bd)
    ev,vr=eig(A)
    assert ev.real.max()<0
    residues=(X@vr)*np.linalg.solve(vr,np.linalg.solve(A,Bd))[None,:]
    errors=[]
    for f in [0.,1,1e3,2e4,1e6,1e7,1e9]:
        z=2j*np.pi*f*unit
        recon=dc+residues@(z/(z-ev)); target=c.solve(f)
        errors.append(float(np.max(abs(recon-target))/(1+np.max(abs(target)))))
    assert max(errors) < 1e-7
    return unit,ev,residues,dc,direct,max(errors)

def finite_unit_step(c):
    unit,ev,r,dc,direct,error=reduce_descriptor(c)
    t=np.unique(np.r_[0.,np.geomspace(1e-10,1e-6,300),np.linspace(1e-6,1e-3,6000)])
    y=(dc[None,:]+np.exp(np.outer(t/unit,ev))@r.T).real
    answer={'frequency_identity_error':error, 'nodes':{}}
    for name in ['IN_A','BUF','ADC_NODE']:
        i=c.idx[c.name(name)]
        answer['nodes'][name]={'min_V_per_unit_step':float(y[:,i].min()),'max_V_per_unit_step':float(y[:,i].max()),'direct_jump_V_per_unit_step':float(direct[i].real)}
    return answer

def evaluate(c10_pf,c11_pf,kind):
    vals={'C10':c10_pf*1e-12,'C11':c11_pf*1e-12}
    out=[]
    for mode in MODES:
        c=Circuit(mode,values=vals)
        freq=np.geomspace(.1,1e7,180)
        err=float(max(abs(c.response(freq)-algebraic_total(freq,mode,vals))))
        assert err < 1e-10
        row={'set':kind,'mode':mode,'C10_pF':c10_pf,'C11_pF':c11_pf,'upper_half_power_Hz':float(c.cutoff()),'gain_V_per_V':c.gain(),'zero_at_3p3_V':c.dc()['ADC_NODE'],'response_at_10kHz_dB':float(20*np.log10(abs(c.response(1e4))/c.gain())),'response_at_20kHz_dB':float(20*np.log10(abs(c.response(2e4))/c.gain())),'MNA_algebra_max_abs_error':err}
        if mode=='DC_WIDE': row.update(ideal_step(c11_pf*1e-12))
        out.append(row)
    return out

def main():
    rows=evaluate(100,100,'nominal')
    rows.extend(evaluate(96,104,'actual_assignment_preferred_C10_96_C11_104'))
    rows.extend(evaluate(104,96,'actual_assignment_alternative_C10_104_C11_96'))
    for name,ends in [('initial_5pct',(95.,105.)),('tolerance_and_temperature_only',(80.75,120.75))]:
        for c10,c11 in itertools.product(ends,repeat=2): rows.extend(evaluate(c10,c11,name))
    for c in [50.,150.,200.]: rows.extend(evaluate(c,c,'illustration_not_a_tolerance'))
    rows.extend(evaluate(100,0,'remove_C11_comparison_only'))
    rows.extend(evaluate(0,100,'remove_C10_comparison_only'))
    # Независимая простая арифметика для DC.
    r=NOMINAL; rt=1/(1/(r['R1']+r['R2'])+1/r['R3']+1/r['R4'])
    k=rt/(r['R1']+r['R2']); zero=3.3*rt/r['R3']
    assert abs(k-rows[0]['gain_V_per_V']) < 1e-13
    assert abs(zero-rows[0]['zero_at_3p3_V']) < 1e-12
    # Пример прямой паразитной связи, такой же выбранный набор, как в R4.
    # Это НЕ измеренная ёмкость PCB и НЕ доказательство защиты.
    pp={'Cr1':2e-12,'Cr2':2e-12,'Csum':26e-12,'Cr18':2e-12,'Cdirect':1e-12,'Cpin':0.,'Cdiff':20e-12}
    finite=[]
    for cc in [0.,50.,80.75,95.,100.,105.,120.75,200.]:
        c=Circuit('DC_WIDE',values={'C11':cc*1e-12},parasitics=pp,finite=(1e5,10e6,25.))
        finite.append({'C11_pF':cc,'C10_pF':100.,'upper_half_power_Hz':float(c.cutoff()),**finite_unit_step(c)})
    actual_finite=[]
    for c10,c11 in [(96.,104.),(104.,96.)]:
        c=Circuit('DC_WIDE',values={'C10':c10*1e-12,'C11':c11*1e-12},parasitics=pp,finite=(1e5,10e6,25.))
        actual_finite.append({'C10_pF':c10,'C11_pF':c11,'upper_half_power_Hz':float(c.cutoff()),**finite_unit_step(c)})
    compact={}
    for name in sorted({r['set'] for r in rows}):
        compact[name]={}
        for mode in MODES:
            ss=[r for r in rows if r['set']==name and r['mode']==mode]
            compact[name][mode]={'cutoff_min_Hz':min(r['upper_half_power_Hz'] for r in ss),'cutoff_max_Hz':max(r['upper_half_power_Hz'] for r in ss)}
            if mode=='DC_WIDE': compact[name][mode].update({'overshoot_min_pct':min(r['overshoot_pct'] for r in ss),'overshoot_max_pct':max(r['overshoot_pct'] for r in ss)})
    result={'revision':'R5_X7R_SENSITIVITY','evidence':'calculation only; hardware NOT TESTED','python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'assumptions':{'other_parts':'R4 nominal; no resistor or other capacitor tolerance sweep here','C10_C11_pF_cases':'initial95..105; initial tolerance*temperature80.75..120.75; illustrative50,150,200; removals comparison only','temperature_only_is_not_full_X7R_bound':True,'DC_bias_aging_frequency_leakage':'not specified for actual parts; not included','parasitics_reference':{'Csum_pF':20,'other_pF':0},'finite_example':{'A0':1e5,'GBW_Hz':1e7,'Ro_ohm':25.,'parasitics_F':pp}},'DC_arithmetic':{'Rth_ohm':rt,'gain':k,'zero_3p3_V':zero,'out_input_minus20_V':zero-20*k,'out_input_plus20_V':zero+20*k,'input_V_per_12bit_code':3.3/4096/k},'summary':compact,'ideal_rows':rows,'finite_illustrative_unit_step_rows':finite,'limitations':['No measured capacitor, hardware, MCU, supply startup or nonlinear model.','Temperature-only endpoints do not include DC bias, aging or frequency.','Finite one-pole model is not a TI macro-model and does not include slew, saturation, protection-diode current or overload recovery.','Finite step is a linear unit input step. Multiplication to larger steps is not a safe operating claim.','C10 is shorted by S2 in WIDE; its capacitance cannot affect ideal WIDE response.','C11 removal changes front feedthrough and invalidates R4 protections/bounds; not recommended.']}
    result['revision']='R5_UNKNOWN_CERAMIC_SUSPECTED_X7R'
    result['title']='Выводные керамические конденсаторы: тип не подтверждён, предположительно X7R'
    result['assumptions']['C10_C11_pF_cases']='user-reported 96/104 in both assignments; previously reported initial5pct95..105; conditional X7R tolerance*temperature80.75..120.75; illustrative50,150,200; removals comparison only'
    result['assumptions']['part_type']='unknown ceramic; X7R only suspected by user'
    result['assumptions']['temperature_case_condition']='80.75..120.75pF is conditional on X7R; not established for actual parts'
    result['limitations'][0]='User-reported capacitor readings only; measurement accuracy, conditions and exact dielectric unknown. No independent component, hardware, MCU or supply-startup tests.'
    actual={'recommended':{'C10_pF_reported':96,'C11_pF_reported':104},'alternative':{'C10_pF_reported':104,'C11_pF_reported':96},'basis':'User reports two leaded capacitors 96pF and104pF, probably X7R. Readings treated as model inputs only, not guaranteed effective capacitance.','decision':'Assign104pF toC11 and96pF toC10. In this model it slightly reduces upper bandwidth, step overshoot and direct fast-edge feedthrough. No added parts.','remaining_unknowns':['Measurement accuracy and test conditions','Exact dielectric and voltage rating','Lead pitch and body size'], 'ideal_rows':[r for r in rows if r['set'].startswith('actual_assignment')],'finite_DC_illustrative_rows':actual_finite}
    result['actual_assignment']=actual
    (HERE/'actual_assignment.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    (HERE/'x7r_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with (HERE/'x7r_cases.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
    print(json.dumps({'DC':result['DC_arithmetic'],'summary':compact,'finite':finite},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
